#include <stdio.h>
#include <string.h>
#define d 10
void rabinKarp(char pattern[], char text[], int q) {
 int m = strlen(pattern);
 int n = strlen(text);
 int i, j;
 int a = 0;
 int b = 0;
 int h = 1;
 for (i = 0; i < m - 1; i++)
 h = (h * d) % q;
 for (i = 0; i < m; i++) {
 a = (d * a + pattern[i]) % q;
 b = (d * b + text[i]) % q;
 }
 for (i = 0; i <= n - m; i++) {
 if (a == b) {
 for (j = 0; j < m; j++) {
 if (text[i + j] != pattern[j])
 break;
 }
 if (j == m) {
 printf("The given pattern is present in the text 
string\n");
 printf("Total Number of shifts needed is %d \n", 
i);
 }
 }
 if (i < n - m) {
 b = (d * (b - text[i] * h) + text[i + m]) % q;
 if (b < 0)
 b = (b + q);
 }
 }
}
int main() {
 char txt[20];
 char pat[20];
 scanf("%[^\n]%*c", txt);
 scanf("%[^\n]%*c", pat);
 int q = 13;
 rabinKarp(pat, txt, q);
 return 0;
}
