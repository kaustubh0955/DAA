#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define max_vertices 100
#define INF INT_MAX
int graph[max_vertices][max_vertices];
int parent[max_vertices];
int visited[max_vertices];
int V, E;
int min(int a, int b) {
 return (a < b) ? a : b;
}
int bfs(int s, int t) {
 int queue[max_vertices], front = 0, rear = 0;
 int i, u, v, path_flow;
 for (i = 0; i < V; i++) {
 parent[i] = -1;
 visited[i] = 0;
 }
 queue[rear++] = s;
 visited[s] = 1;
 parent[s] = -1;
 while (front < rear) {
 u = queue[front++];
 for (v = 0; v < V; v++) {
 if (!visited[v] && graph[u][v] > 0) {
 parent[v] = u;
 visited[v] = 1;
 queue[rear++] = v;
 }
 }
 }
 if (!visited[t])
 return 0;
 path_flow = INF;
 for (v = t; v != s; v = parent[v]) {
 u = parent[v];
 path_flow = min(path_flow, graph[u][v]);
 }
 for (v = t; v != s; v = parent[v]) {
 u = parent[v];
 graph[u][v] -= path_flow;
 graph[v][u] += path_flow;
 }
 return path_flow;
}
int max_flow(int s, int t) {
 int flow = 0;
 int path_flow;
 while ((path_flow = bfs(s, t)) != 0) {
 flow += path_flow;
 }
 return flow;
}
void add_edge(int u, int v, int w) {
 graph[u][v] = w;
}
int main() {
 int s = 9, t = 10;
 V = 11;
 E = 18;
 add_edge(s, 0, 5);
 add_edge(s, 1, 10);
 add_edge(s, 2, 5);
 add_edge(0, 3, 10);
 add_edge(1, 0, 15);
 add_edge(1, 4, 20);
 add_edge(2, 5, 10);
 add_edge(3, 4, 25);
 add_edge(3, 6, 10);
 add_edge(4, 2, 5);
 add_edge(4, 7, 30);
 add_edge(5, 7, 5);
 add_edge(5, 8, 10);
 add_edge(7, 3, 15);
 add_edge(7, 8, 5);
 add_edge(6, t, 5);
 add_edge(7, t, 15);
 add_edge(8, t, 10);
 printf("The maximum flow of the given network is 
%d\n", max_flow(s, t));
 return 0;
}