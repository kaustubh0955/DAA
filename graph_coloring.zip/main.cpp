#include <bits/stdc++.h>
using namespace std;
class Edge{
public:
int src, dest, weight;
Edge() {}
Edge(int src, int dest, int weight){
this->src = src;
this->dest = dest;
this->weight = weight;
}
};
class Graph{
public:
int V, E;
Edge edges[];
Graph(int V, int E){
this->V = V;
this->E = E;
}
};
int **adjmatrix(Graph *g){
int V = g->V;
int E = g->E;
int **mat = new int *[V];
for (int i = 0; i < V; i++){
mat[i] = new int[V];
for (int j = 0; j < V; j++){
mat[i][j] = 0;
}
}
for (int i = 0; i < E; i++){
int u = g->edges[i].src;
int v = g->edges[i].dest;
mat[u][v] = g->edges[i].weight;
}
return mat;
}
bool isSafe(int **g, int color[], int c, int V, int x){
for (int i = 0; i < V; i++){
if (g[x][i] && c == color[i])
return false;
}
return true;
}
bool graphColorUntil(int **g, int m, int color[], int a, int V){
if (a == V)
return true;
for (int c = 1; c <= m; c++){
if (isSafe(g, color, c, V, a)){
color[a] = c;
if (graphColorUntil(g, m, color, a + 1, V))
return true;
color[a] = 0;
}
}
return false;
}
void graphColor(Graph *g, int m){
int **mat = adjmatrix(g);
int V = g->V;
int color[V];
for (int i = 0; i < V; i++){
color[i] = 0;
}
if (!graphColorUntil(mat, m, color, 0, V)){
cout << "NO";
return;
}
for (int i = 0; i < V; i++){
cout << color[i] << " ";
}
}
int main(){
Graph graph(4, 10);
graph.edges[0] = Edge(0, 1, 1);
graph.edges[1] = Edge(0, 2, 1);
graph.edges[2] = Edge(0, 3, 1);
graph.edges[3] = Edge(1, 0, 1);
graph.edges[4] = Edge(1, 2, 1);
graph.edges[5] = Edge(2, 0, 1);
graph.edges[6] = Edge(2, 1, 1);
graph.edges[7] = Edge(2, 3, 1);
graph.edges[8] = Edge(3, 0, 1);
graph.edges[9] = Edge(3, 2, 1);
graphColor(&graph, 3);
}
