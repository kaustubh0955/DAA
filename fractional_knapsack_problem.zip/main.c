#include <stdio.h>
#include <stdlib.h>

struct item {
    int profit;
    int weight;
};

int compare_items(const void *a, const void *b) {
    struct item *item1 = (struct item *)a;
    struct item *item2 = (struct item *)b;
    double value1 = (double)item1->profit / item1->weight;
    double value2 = (double)item2->profit / item2->weight;
    if (value1 > value2) {
        return -1;
    } else if (value1 < value2) {
        return 1;
    } else {
        return 0;
    }
}

double fractional_knapsack(int n, int W, struct item items[]) {
    qsort(items, n, sizeof(struct item), compare_items);
    double total_profit = 0;
    int remaining_weight = W;
    for (int i = 0; i < n; i++) {
        if (remaining_weight == 0) {
            break;
        }
        if (items[i].weight <= remaining_weight) {
            total_profit += items[i].profit;
            remaining_weight -= items[i].weight;
        } else {
            total_profit += ((double)remaining_weight / items[i].weight) * items[i].profit;
            remaining_weight = 0;
        }
    }
    return total_profit;
}

int main() {
    int n, W;
    printf("Enter the number of items: ");
    scanf("%d", &n);
    printf("Enter the capacity of the knapsack: ");
    scanf("%d", &W);
    struct item items[n];
    for (int i = 0; i < n; i++) {
        printf("Enter the profit and weight of item %d: ", i+1);
        scanf("%d %d", &items[i].profit, &items[i].weight);
    }
    double max_profit = fractional_knapsack(n, W, items);
    printf("Maximum profit = %.2f\n", max_profit);
    return 0;
}