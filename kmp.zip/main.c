#include <stdio.h>
#include <string.h>
int KMP(char *str, char *pattern, int *shifts) {
 int n = strlen(str);
 int m = strlen(pattern);
 int i, j;
 int lps[m];
 lps[0] = 0;
 i = 1;
 j = 0;
 while (i < m) {
 if (pattern[i] == pattern[j]) {
 j++;
 lps[i] = j;
 i++;
 }
 else {
 if (j != 0) {
 j = lps[j-1];
 }
 else {
 lps[i] = 0;
 i++;
 }
 }
 }
 i = 0;
 j = 0;
 int count = 0;
 while (i < n) {
 if (pattern[j] == str[i]) {
 i++;
 j++;
 }
 if (j == m) {
 shifts[count++] = i-j;
 j = lps[j-1];
 }
 else if (i < n && pattern[j] != str[i]) {
 if (j != 0) {
 j = lps[j-1];
 }
 else {
 i++;
 }
 }
 }
 return count;
}
int main() {
 char str[1000], pattern[1000];
 int shifts[1000], count, i;
 scanf("%[^\n]s", str);
 scanf(" %[^\n]s", pattern);
 count = KMP(str, pattern, shifts);
 if (count > 0) {
 printf("The given pattern is found in the string 
\n");
 for (i = 0; i < count; i++) {
 printf("Total number of shifts took place for 
the match is %d ", shifts[i]);
 }
 
 }
 else {
 printf("Pattern not found.\n");
 }
 return 0;
}
