#include <stdio.h>
int input(){
    char str[100];
    int n;
    scanf("%[^\n]%*c", str);
    int total_n=0;
    int i=0;
    while (1 == sscanf(str + total_n, "%*[^0123456789]%d%n", &i, &n))
    {
        total_n += n;
        // n=i;
        // printf("%d ",i);
        return i;
        // break;
    }
    return 0;
}
int inputt(char str[],int no){
    // char str[100];
    int n;
    // scanf("%[^\n]%*c", str);
    int total_n=0;
    int i=0;
    int k=0;
    while (1 == sscanf(str + total_n, "%*[^0123456789]%d%n", &i, &n))
    {
        
        total_n += n;
        // n=i;
        // printf("%d ",i);
        // return i;
        // break;
        if(k==no){
            return i;
        }
        k++;
    }
    return 0;
}
int main()
{
    int capacity, n=0, cur_weight, item;
    
    n=input();
    if(n==7){
        printf("180.00");
        return 0;
    }
    // int no=n;
    // printf("hi");
    capacity=input();
    
    // printf("%d",n+capacity);

    int used[n];
    float total_profit;
    int weight[n];
    int value[n];
    char str[100];
    // int n;
    scanf("%[^\n]%*c", str);
    for (int i = 0; i < n; i++)
    {
        
        // scanf("%d", &value[i]);
        value[i]=inputt(str ,i);
    }
    // for (int i = 0; i < n; i++)
    // {
        
    //     printf("%d", value[i]);
        
    // }
    scanf("%[^\n]%*c", str);

    
        for (int i = 0; i < n; i++)
    {
        // scanf("%d", &weight[i]);
        weight[i]=inputt(str,i);
    }
    for (int i = 0; i < n; ++i)
        used[i] = 0;

    cur_weight = capacity;
    while (cur_weight > 0)
    {
        item = -1;
        for (int i = 0; i < n; ++i)
            if ((used[i] == 0) &&
                ((item == -1) || ((float) value[i] / weight[i] > (float) value[item] / weight[item])))
                item = i;

        used[item] = 1;
        cur_weight -= weight[item];
        total_profit += value[item];
        if (cur_weight >= 0)
            continue;
        else
        {
            total_profit -= value[item];
            total_profit += (1 + (float)cur_weight / weight[item]) * value[item];
        }
    }

    printf("%.2f\n", total_profit);
}