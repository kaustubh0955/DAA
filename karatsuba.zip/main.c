#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int digitCount(int n)
{
    int count=0;
    while(n)
    {
        count+=1;
        n/=10;
    }
    return count;
}
int findMax(int k,int l)
{
    if(k>l)
    
    {
        return k;
    }
    else
    {
        return l;
    }
}
int power(int b,int e)
{
    int value=1;
    while(e)
    {
        value*=b;
        e--;
    }
    return value;
}
long int karatsuba(int X,int Y)
{
    long int sol;
    if((X<10)&&(Y<10))
    return X*Y;
    else
    {
        int n,nby2;
        n=findMax(digitCount(X),digitCount(Y));
        nby2=ceil((float)n/2);
        
        int a,b,c,d;
        a=X/power(10,nby2);
        b=X%power(10,nby2);
        c=Y/power(10,nby2);
        d=Y%power(10,nby2);
        
        int s1,s2,s3,s4;
        
        s1=karatsuba(a,c);
        s2=karatsuba(b,d);
        s3=karatsuba(a+b,c+d);
        s4=s3-s2-s1;
        
        sol=((s1*power(10,n))+(s4*power(10,nby2))+s2);
    }
}
int main()
{
    int X,Y;
    scanf("%d",&X);
    scanf("%d",&Y);
    long int sol=karatsuba(X,Y);
    printf("X * Y =%ld",sol);
}