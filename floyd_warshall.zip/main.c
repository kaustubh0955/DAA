#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define nv 4
#define I 999
void printMatrix(int matrix[][nv]);
void floydWarshall(int graph[][nv]);
int main() {
 int graph[nv][nv];
 char input[4];
 
 for (int i = 0; i < nv; i++) {
 for (int j = 0; j < nv; j++) {
 scanf("%s", input);
 if (strcmp(input, "500") == 0) {
 graph[i][j] = 500;
 } else {
 graph[i][j] = atoi(input);
 }
 }
 }
 floydWarshall(graph);
 return 0;
}
void floydWarshall(int graph[][nv]) {
 int matrix[nv][nv], i, j, k;
 for (i = 0; i < nv; i++)
 for (j = 0; j < nv; j++)
 matrix[i][j] = graph[i][j];
 
 for (k = 0; k < nv; k++) {
 for (i = 0; i < nv; i++) {
 for (j = 0; j < nv; j++) {
 if (matrix[i][k] + matrix[k][j] < matrix[i][j])
 matrix[i][j] = matrix[i][k] + matrix[k][j];
 }
 }
 }
 printMatrix(matrix);
}
void printMatrix(int matrix[][nv]) {
 for (int i = 0; i < nv; i++) {
 for (int j = 0; j < nv; j++) {
 if (matrix[i][j] == 500)
 printf("%s ", "500");
 else
 printf("%d ", matrix[i][j]);
 }
 printf("\n");
 }
}