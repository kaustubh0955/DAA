#include <stdio.h>
#include <string.h>
int x=0;
void print(int arr[])
{
 for (int i=0;i<x;i++)
 {
 if (i!=x-1)
 printf(" %d",arr[i]);
 if (i==x-1)
 printf(" and %d",arr[i]);
 }
}
void search(char* pat, char* txt , int arr[])
{
int M = strlen(pat)-1;
int N = strlen(txt)-1;
for (int i = 0; i <= N - M; i++) {
int j;
for (j = 0; j < M; j++)
if (txt[i + j] != pat[j])
break;
if (j== M){
arr[x]=i/2;
 x++;
}
}
print(arr);
}
int main()
{
char txt[50],pat[50];
int arr[30];
fgets(txt,50,stdin);
 fgets(pat,50,stdin);
 printf("Pattern found at");
search(pat, txt,arr);
return 0;
}