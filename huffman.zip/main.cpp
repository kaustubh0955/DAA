//program for huffman coding
#include <iostream>
using namespace std;
class Node{
public:
char data;
int freq;
Node *left;
Node *right;
Node(char data,int freq){
this->data=data;
this->freq=freq;
left=NULL;
right=NULL;
}
};
class minHeap{
public:
int size;
int capacity;
Node **arr;
minHeap(int capacity){
this->capacity=capacity;
size=0;
arr=new Node*[capacity];
}
};
void swap(Node **a,Node **b){
Node *temp=*a;
*a=*b;
*b=temp;
}
void minHeapify(minHeap *minHeap,int idx){
int smallest=idx;
int left=2*idx+1;
int right=2*idx+2;
if(left<minHeap->size && minHeap->arr[left]->freq<minHeap->arr[smallest]-
>freq){
smallest=left;
}
if(right<minHeap->size && minHeap->arr[right]->freq<minHeap-
>arr[smallest]->freq){
smallest=right;
}
if(smallest!=idx){
swap(&minHeap->arr[smallest],&minHeap->arr[idx]);
minHeapify(minHeap,smallest);
}
}
int isSizeOne(minHeap *minHeap){
return (minHeap->size==1);
}
Node *extractMin(minHeap *minHeap){
Node *temp=minHeap->arr[0];
minHeap->arr[0]=minHeap->arr[minHeap->size-1];
--minHeap->size;
minHeapify(minHeap,0);
return temp;
}
void insertMinHeap(minHeap *minHeap,Node *node){
++minHeap->size;
int i=minHeap->size-1;
while(i && node->freq<minHeap->arr[(i-1)/2]->freq){
minHeap->arr[i]=minHeap->arr[(i-1)/2];
i=(i-1)/2;
}
minHeap->arr[i]=node;
}
void buildMinHeap(minHeap *minHeap){
int n=minHeap->size-1;
int i;
for(i=(n-1)/2;i>=0;--i){
minHeapify(minHeap,i);
}
}
void printArr(int arr[],int n){
int i;
for(i=0;i<n;++i){
cout<<arr[i];
}
cout<<endl;
}
int isLeaf(Node *root){
return !(root->left) && !(root->right);
}
minHeap *createMinHeap(char data[],int freq[],int size){
minHeap *minHeap=new class minHeap(size);
for(int i=0;i<size;++i){
minHeap->arr[i]=new Node(data[i],freq[i]);
}
minHeap->size=size;
buildMinHeap(minHeap);
return minHeap;
}
Node *buildHuffmanTree(char data[],int freq[],int size){
Node *left,*right,*top;
minHeap *minHeap=createMinHeap(data,freq,size);
while(!isSizeOne(minHeap)){
left=extractMin(minHeap);
right=extractMin(minHeap);
top=new Node('$',left->freq+right->freq);
top->left=left;
top->right=right;
insertMinHeap(minHeap,top);
}
return extractMin(minHeap);
}
void printCodes(Node *root,int arr[],int top){
if(root->left){
arr[top]=0;
printCodes(root->left,arr,top+1);
}
if(root->right){
arr[top]=1;
printCodes(root->right,arr,top+1);
}
if(isLeaf(root)){
cout<<root->data<<": ";
printArr(arr,top);
}
}
void HuffmanCodes(char data[],int freq[],int size){
Node *root=buildHuffmanTree(data,freq,size);
int arr[100],top=0;
printCodes(root,arr,top);
}
int main(){
int n;
cin>>n;
char arr[n];
int freq[n];
for(int i=0; i<n;i++){
cin>>arr[i];
cin>>freq[i];
}
HuffmanCodes(arr,freq,n);
return 0;
}
