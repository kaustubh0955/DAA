#include<bits/stdc++.h>
using namespace std;
int **dp;
int MatrixChainMultiplication(int mat[],int low, int high){
if(low==high)
return 0;
if(dp[low][high]!=-1)
return dp[low][high];
dp[low][high]=INT_MAX;
for(int k=low;k<high;k++){
int cost=MatrixChainMultiplication(mat, low, k)+
MatrixChainMultiplication(mat, k+1, high)+
mat[low-1]*mat[k]*mat[high];
if(cost<dp[low][high])
dp[low][high]=cost;
}
return dp[low][high];
}
int main(){
// This matrix chain of length 5 represents 
// 4 matrices of dimensions as follows -
// 2*4, 4*6, 6*8, and 8*6.
int mat[]={2, 4, 6, 8, 6};
int n=sizeof(mat)/sizeof(mat[0]);
dp=new int*[n];
for(int i=0;i<n;i++){
dp[i]=new int[n];
for(int j=0;j<n;j++)
dp[i][j]=-1;
}
cout<<"Minimum number of steps are - ";
cout<<MatrixChainMultiplication(mat, 1, n-1);
return 0;
}
