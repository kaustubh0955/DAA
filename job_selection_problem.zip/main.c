#include <stdio.h>
int N,M;
int cost(int arr[N][M])
{
 int cost= 0,min,pos;
 int l[M];
 for(int i=0;i<M;i++)
 {
 l[i]=0; 
 }
 for(int i=0;i<N;i++)
 {
 min=arr[i][0];
 pos=0;
 for(int j=0;j<M;j++)
 {
 if(arr[i][j]<min && l[j]!=1)
 {
 min=arr[i][j];
 pos=j;
 }
 }
 cost=cost+min;
 l[pos]=1;
 printf("W%d-J%d\n",i+1,pos+1);
 }
 return cost;
}
int main()
{
 int n,m,y;
 scanf("%d%d",&n,&m);
 N=n;
 M=m;
 int arr[n][m];
 for(int i=0;i<n;i++)
 {
 for (int j=0;j<m;j++)
 {
 scanf("%d", &y);
 arr[i][j]=y;
 }
 }
 int c=cost(arr);
 printf("%d",c);
 
}
